import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CategoryComponent } from './Components/category/category.component';
import { CustomerComponent } from './Components/customer/customer.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { PolicyComponent } from './Components/policy/policy.component';
import { QueryComponent } from './Components/query/query.component';
import { AddcategoryComponent } from './Components/category/addcategory/addcategory.component';
import { ViewcategoryComponent } from './Components/category/viewcategory/viewcategory.component';
import { UpdatecategoryComponent } from './Components/category/updatecategory/updatecategory.component';
import { DeletecategoryComponent } from './Components/category/deletecategory/deletecategory.component';

const routes: Routes = [
  {path:"", component:DashboardComponent},
  {path:"user", component:CustomerComponent},
  {path:"category", component:CategoryComponent},
  {path:"policy", component:PolicyComponent},
  {path:"query", component:QueryComponent},
  {path:"addcategory", component:AddcategoryComponent},
  {path:"viewcategory", component:ViewcategoryComponent},
  {path:"updatecategory", component:UpdatecategoryComponent},
  {path:"deletecategory", component:DeletecategoryComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
