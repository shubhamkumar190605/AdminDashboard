import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  total_user:number
  total_policy:number
  total_category:number
  total_question:number
  total_policy_holder:number
  approved_policy_holder:number
  disapproved_policy_holder:number
  waiting_policy_holder:number
  constructor() { }

  ngOnInit(): void {
  }

}
