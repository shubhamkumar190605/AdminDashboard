import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatecategory',
  templateUrl: './updatecategory.component.html',
  styleUrls: ['./updatecategory.component.css']
})
export class UpdatecategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
