import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcategory',
  templateUrl: './viewcategory.component.html',
  styleUrls: ['./viewcategory.component.css']
})
export class ViewcategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
