import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletecategory',
  templateUrl: './deletecategory.component.html',
  styleUrls: ['./deletecategory.component.css']
})
export class DeletecategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
